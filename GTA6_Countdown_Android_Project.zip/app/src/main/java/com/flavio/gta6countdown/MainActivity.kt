package com.flavio.gta6countdown

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(32, 32, 32, 32)
            setBackgroundColor(0xFF101018.toInt())
        }
        val title = TextView(this).apply {
            text = "GTA VI COUNTDOWN"
            textSize = 28f
            setTextColor(0xFFFFD0E8.toInt())
            gravity = Gravity.CENTER
        }
        val desc = TextView(this).apply {
            text = "\nContagem até 19/11/2026, 00:00 (horário de Brasília).\n\nO contador aparece como uma faixa flutuante no topo da tela. O Android exige autorização para isso."
            textSize = 16f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        val start = Button(this).apply {
            text = "ATIVAR CONTADOR NO TOPO"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val intent = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivityForResult(intent, 100)
                } else startOverlay()
            }
        }
        val stop = Button(this).apply {
            text = "DESATIVAR CONTADOR"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CountdownOverlayService::class.java))
                Toast.makeText(this@MainActivity, "Contador desativado", Toast.LENGTH_SHORT).show()
            }
        }
        layout.addView(title)
        layout.addView(desc)
        layout.addView(start)
        layout.addView(stop)
        setContentView(layout)
    }

    @Deprecated("Deprecated in Android, kept for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && Settings.canDrawOverlays(this)) startOverlay()
    }

    private fun startOverlay() {
        val intent = Intent(this, CountdownOverlayService::class.java)
        startForegroundService(intent)
        Toast.makeText(this, "Contador ativado!", Toast.LENGTH_SHORT).show()
    }
}
