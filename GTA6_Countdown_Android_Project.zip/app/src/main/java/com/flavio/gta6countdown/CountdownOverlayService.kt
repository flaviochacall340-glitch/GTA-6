package com.flavio.gta6countdown

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class CountdownOverlayService : Service() {
    private lateinit var wm: WindowManager
    private var badge: TextView? = null
    private val handler = Handler(Looper.getMainLooper())
    private val target = 1795057200000L // 2026-11-19 00:00:00 America/Sao_Paulo (UTC-03)
    private val tick = object : Runnable {
        override fun run() {
            badge?.text = makeCountdown()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        val notification: Notification = if (Build.VERSION.SDK_INT >= 26) {
            Notification.Builder(this, "gta_countdown")
                .setContentTitle("GTA VI Countdown ativo")
                .setContentText("A contagem regressiva está aparecendo no topo da tela.")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setOngoing(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            Notification.Builder(this)
                .setContentTitle("GTA VI Countdown ativo")
                .setContentText("Contagem regressiva ativa")
                .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
                .setOngoing(true).build()
        }
        startForeground(61, notification)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        badge = TextView(this).apply {
            text = "GTA VI  •  carregando..."
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(0xE6101018.toInt())
            setPadding(14, 8, 14, 8)
            gravity = Gravity.CENTER
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 28
        }
        try { wm.addView(badge, params) } catch (_: Exception) {}
        handler.post(tick)
    }

    private fun makeCountdown(): String {
        val diff = target - System.currentTimeMillis()
        if (diff <= 0) return "🎮 GTA VI • CHEGOU O DIA!"
        val totalSeconds = diff / 1000
        val days = totalSeconds / 86400
        val hours = (totalSeconds % 86400) / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return "GTA VI  •  %d DIAS  %02d:%02d:%02d".format(Locale.getDefault(), days, hours, minutes, seconds)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel("gta_countdown", "GTA VI Countdown", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        try { badge?.let { wm.removeView(it) } } catch (_: Exception) {}
        badge = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
