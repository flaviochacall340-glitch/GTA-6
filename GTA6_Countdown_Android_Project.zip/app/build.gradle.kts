plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.flavio.gta6countdown"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.flavio.gta6countdown"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
